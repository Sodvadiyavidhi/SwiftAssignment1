import UIKit
//Question 1
let nameArray = ["Vidhi","John","Veronica"]
let hobbyArray = ["Cooking","Surfing","Gardening"]
func searchFLower(using x:String) -> Bool {
    
            if nameArray.contains(x) || hobbyArray.contains(x){
                return true
            }
            else{
                return false
            }
}
let answer1 = searchFLower(using: "John")
print(answer1)

//Question 2
var array1    =
[1,3,4,5,8,9,9,4,3,5,6,4,3,2,5,1,7,7,7,2,2,2,3,4,1,1,1,3,1,4,1,5,1,6,1,7,1,8,1]

var storeDictionary = [Int: Int]()

array1.forEach { storeDictionary[$0] = (storeDictionary[$0] ?? 0) + 1 }
if let (value, count) = storeDictionary.max(by: {$0.1 < $1.1}) {
    print("\(value) is the most common number that is occuring \(count) times")
}

//Question 3a
let person = (firstname: "Vidhi",lastname: "Sodvadiya",address: "111,College Crescent")
var firstname = person.firstname
var lastname = person.lastname
var address = person.address

//Question 3b
let numbers = (s1:5 , s2:7, s3:10 , s4:12 , s5:6 )
var s1 = numbers.0
var s2 = numbers.1
var s3 = numbers.2
var s4 = numbers.3
var s5 = numbers.4
let size = Mirror(reflecting: numbers).children.count
func sum() -> String{
    let sum = s1 + s2 + s3 + s4 + s5
    let average = sum/size
    return ("The sum is \(sum) and the average is \(average).")
}
let answer2 = sum()
print(answer2)

//Question 4
struct Detail{
    let name : String?
    let age : Int?
}
let unwrap = Detail(name: "Vidhi", age: 19)
let n = unwrap.self
print(n as Any)

//Question 5
func swapTwoValues<T>(_ a: inout T, _ b: inout T) {
    let temporaryA = a
    a = b
    b = temporaryA
    print("The value for a is  \(a) and the value for b is \(b).")
}
var num1 = 12
var num2 = 6
swapTwoValues(&num1 , &num2)

var string1 = "First"
var string2 = "Last"
swapTwoValues(&string1 , &string2)

var doub1 = 5.7
var doub2 = 9.1
swapTwoValues(&doub1 , &doub2)

//Question 6
var books:Set<String> = ["Novel","Comic","Fantasy","Thriller"]
books.insert("Poems")
func contain() -> Bool{
    if books.contains("Poems"){
        return true
    }
    else{
        return false
    }
}
let answer3 = contain()
print(answer3)

//Question 7a
let names = ["Brandon","Jasmeet","Amit","Kim"]
let checkcount = names.filter { $0.count < 6}
print(checkcount)
//Question 7b
let numofChar = names.map { $0.count }
print(numofChar)
